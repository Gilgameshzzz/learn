# 什么是变量
"""
在程序中可以通过变量来存储数据（容器）
"""

# 怎么声明变量  
"""
严格来说，python中的变量是不需要声明的，直接通过赋值符号(=)给变量赋值，就是在声明变量 。
因为python是动态语言，在声明变量的时候，不需要指定变量的类型。并且同一个变量可以赋不同类型的值


格式: 变量名 = 值
变量名：标识符，PEP8的命名方式（所有的字母都小写，多个单词之间用下划线隔开，例如: user_name）
 
驼峰式命名: 第一个单词首字母小写，后边每个单词的首字母都大写(例如:userName)
"""

# 声明了一个变量age,并且赋值为18
age = 18

# 使用变量的时候，就相当于使用变量中存的值
print(age)   


student_age = 20
print(type(student_age))


# 1.如果重新给一个变量赋值，那么新赋的值会覆盖原来的值
# 2.同一个变量可以赋不同类型的值
student_age = 'abc'
print(student_age, type(student_age))


# print(student_name)  # NameError



# 补充：
# 一个数据有type(类型)、id(数据存储在计算机中的地址)和value(值)三个属性
# 变量存储数据的时候，有两种情况。第一情况：存value ---> 数字类型、字符串， 第二种情况：存id  ----> 字典、列表、集合、元祖、类的对象等
number = 10
number2 = 10
print(id(number),id(number2))





