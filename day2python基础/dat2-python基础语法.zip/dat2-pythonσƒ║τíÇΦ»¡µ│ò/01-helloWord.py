# 1.常用快捷方式：
#  control + /  ----- 单行注释
#  control + s  ----- 保存
#  control + b  ----- 编译(编译执行)
#  control + n  ----- 新建文件
#  control + c  ----- 复制
#  control + v  ----- 粘贴 
#  control + a  ----- 全选
#  control + x  ----- 剪切
#  control + z  ----- 撤销
#  control + y /  control + shift + z ---- 反撤销
#  按住control不放，让鼠标可以同时在多个位置设置光标
#  control + f  ----- 弹出搜索框


# 2.print函数是python内置函数，作用是在控制台打印print后面()里面的任何内容
# ()里面的单引号，是字符串的标志，而不是内容
# 在python2.x中 print 'hello world'
# 在python3.x中 print后面需要括号
# A.B.C版本号。A ---> 重大修改(不向下兼容)  B ---> 添加新的功能   C ---> 修复bug
print('hello world~')
print('你好')  

