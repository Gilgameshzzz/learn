


# 数学运算符、比较运算符、逻辑运算符、赋值运算符、位运算符(针对二进制的每一位)

# 1.数学运算符(+、-、*、/、%、**、//)
# + : 求和
# 注意: 求和操作，+两边必须是数字类型
# True --> 1  False --> 0
print(10+20.4, True+1)  
number = 100 + 11
print(number)

# - : 求差
print(100-12)

# * : 求乘积
print(3.12*2)
number = 3 * 9  

# / : 求商
print(4/2)
print(5/2)

# % : 求上个数相除的余数 
#  10 / 2 = 5...0
print(3%2)
print(109%10)  

# ** : 幂运算
# x ** y: 求x的y次方
# 浮点数在计算中存储的时候，有的时候会有一定的误差
number = 4.2 ** 3
print(number) 

# // : 整除
# 求商，但是只取商的整数部分
print(5//2)

# 取一个二位整数的十位数（78）：
print(78//10)


# 取2345中的4：
print(2345%100//10)
print(2345//10%10)


# 2.比较运算符
"""
>、< 、==、>= 、<=、!=

比较运算符的结果全是布尔: Ture、False
"""

# 1.>
# x > y:  判断x是否大于y,如果是结果是Ture，否则是False

resulut = 10 > 20   
print(resulut, 100 > 20)  


# 2.<
print(10 < 20)


# 3.==
# x == y: 如果x和y相等，结果就是True,否则是False
number = 12.5
number2 = 12
print(number == number2)

# 4.>=、 <= 
10 >= 5   # True
10 >= 10  # True

#5. !=
# x != y : 如果x和y不相等，结果是True,否则是False


# 6. 在python中，可以像数学中一样，连续判断
number = 15
resulut = 10<number<20  # 判断number是否在10到20之间
print(resulut)


# 3.逻辑运算符  
"""
与(and)、或(or)、非(not)

# 1.
逻辑运算符的运算数据是布尔值，结果也是布尔值
布尔1 and  布尔2: 两个都为Ture结果才是True,只要有一个是False,结果就是False。  并且
需要两个或者多个条件同时满足，就使用逻辑与(and)


布尔1 or  布尔2: 只要有一个是Ture,结果就是Ture。两个都是False结果才是False。  或者
需要两个或者多个条件中满足一个就可以，就使用逻辑或(or)


not 布尔1: 如果是True,结果就是False;如果是False,结果就是True。
需要不满足某个条件的时候才为True
"""
# 写一个条件，判断一个人的年龄是否满足青年的条件(年龄大于18并且小于28,而是还不能是20岁)
age = 30
print(age>18 and age<28 and age!=20)

# 平均成绩大于90分，或者操评分大于100,并且英语成绩还不能小于80分
score = 95
score2 = 90
english = 90
print('===:',score>90 or score2>100 and english >= 80)

# 成绩不低于60分
score = 70
print(score >= 60)
print(not score<60)


not age > 10
not True
not False

# 4.赋值运算符  
"""
=, += , -= , *= ,/= ,%= ,**=, //=

赋值运算符的作用: 将赋值符号右边的表达式的值赋给左边的变量
表达式: 有结果的的语句，例如: 10, 'abc', 10+20, 30>10.5等
赋值符号的左边必须是变量


赋值符号，是先算右边的结果，然后再把结果赋给左边的变量
"""
number = 100


number += 10  # 相等于:number = number + 10
print(number)


number *= 2   # number = number * 2
print(number)


# 5. 运算符的优先级
"""
10+20*3-5/2 = 10+60-2.5 = 67.5   --- 数学运算顺序

优先级从低到高: 赋值运算符<逻辑运算符<比较运算符<算术运算符
算术运算符中: 先幂运算再乘除取余取整再加减

如果你不确定运算顺序，可以通过添加括号来改变运算顺序。有括号就先算括号里面的

"""
resulut =  10 + 20 > 15 and 7 * 8 < 30 + 60
# resulut = 30 > 15 and 56 < 90
# resulut = True and True
# result = True
print(resulut)

print(10 + 20 * 3 / 2 - 10%3)  
# 10+30-1 
# 39

print(10*2**2)


print(10 + 20 * 3 / (2 - 10)%3) 
# 10 + 20 * 3 /(-8)%3
# 10 + 60/(-8)%3
# 10 + (-7.5)%3
# 10 + 1.5
# 11.5













