# 1. + : 字符串拼接
# 字符串1+字符串2
str1 = 'hello' +' '+'Python'
print(str1)

# 注意: + 号两边要么都是数字，要么都是字符串。不能是一个数字一个字符串
# print(12+'34')



# 2. * : 让字符串重复
# 字符串*整数
str1 = 'abc' * 3
print(str1)

str2 = 'a'*10
print(str2)


# 3. in 
# 字符串1 in 字符串2 ： 判断字符串1是否在字符串2中 --> 在就是True,不在是Fasle
result = 'aa' in 'abaaac'
print(result)

# 4. not in
# 字符串1 not in 字符串2 : 判断字符串1是否不在字符串2中  --> 不在就是True,在是False
result = '123' not in 'abc'
print(result)

# 5.格式字符串
# 格式: '占位符1占位符2'%(值1,值2)
str1 = 'abc%s12%s3' % ('>>>','!!!')

print(str1)

# %s --> 字符串占位符(格式符)
# %d --> 整数占位符(格式符)
# %f --> 浮点数占位符
# %c --> 长度是1的字符串占位符(字符占位符)---可以给一个字符，也可以给字符的编码值
str2 = '-%s-%d-%f-%c-%c-' % ('我是字符串',123,12.4,'k',97)
print(str2)

# %.nf : 使用n值限制小数点后面的小数的位数（默认六位小数）
str3 = '金额:%.2f元' % (100)
print(str3)

# 如果后面没有加%，那么这个字符串只是一个普通的字符串
str3 = '金额L%f元'
print(str3)


# %x和%X --> 十六进制数据占位符
number = 15
# XXX的十六进制是XXXXX
str4 = '%d的十六进制是0X%x' % (number, number)
print(str4)


# 6.格式化输出
name = '路飞'
age = 17
# xx今年xx岁
print('%s今年%d岁' % (name, age))
print('%x' % (id(name)))






